
import { useState } from "react";

function FeedbackForm() {
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [comentario, setComentario] = useState("");

  function enviarFeedback(event) {
    event.preventDefault();

    if (!nome.trim() || !email.trim() || !comentario.trim()) {
      alert("Por favor, preencha todos os campos!");
      return;
    }

    alert(
      `Feedback enviado!\n\nNome: ${nome}\nEmail: ${email}\nComentário: ${comentario}`
    );

    setNome("");
    setEmail("");
    setComentario("");
  }

  return (
    <form onSubmit={enviarFeedback} className="formulario">
      <h2>Envie seu feedback</h2>
      <p>Sua opinião é muito importante para nós!</p>

      <label htmlFor="nome">Nome</label>
      <input
        id="nome"
        type="text"
        placeholder="Digite seu nome"
        value={nome}
        onChange={(e) => setNome(e.target.value)}
      />

      <label htmlFor="email">E-mail</label>
      <input
        id="email"
        type="email"
        placeholder="Digite seu e-mail"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />

      <label htmlFor="comentario">Comentário</label>
      <textarea
        id="comentario"
        placeholder="Escreva seu comentário..."
        rows="5"
        value={comentario}
        onChange={(e) => setComentario(e.target.value)}
      />

      <button type="submit">Enviar feedback</button>
    </form>
  );
}

export default FeedbackForm;
