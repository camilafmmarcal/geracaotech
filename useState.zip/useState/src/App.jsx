
import FeedbackForm from "./FeedbackForm.jsx";
import "./App.css";

function App() {
  return (
    <main className="container">
      <FeedbackForm />
    </main>
  );
}

export default App;
